import 'core/js/fixes/img.lazyload';

define([
  './themeView'
], function(ThemeView) {

  var ThemeArticleView = ThemeView.extend({

    className: function() {},

    setCustomStyles: function() {},

    onRemove: function() {}

  });

  return ThemeArticleView;

});

Folder location for any global template overrides. The file name of the template indicates the element it affects.
